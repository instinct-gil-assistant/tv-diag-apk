package com.instinct.tvdiag;

import android.app.ActivityManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.*;

/** Android-side bridge for the memory cleaner: enumerates killable apps and kills. */
final class AppKiller {

    static final class App {
        String pkg, label; boolean system, hasLauncher; int runningImportance = 1001; // 1001 = no visible process
    }

    /** Most recent foreground app other than ourselves, from usage events. Null without usage access. */
    static String mostRecentOtherApp(Context c) {
        if (!Collector.hasUsage(c)) return null;
        try {
            UsageStatsManager us = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = us.queryEvents(now - 3L * 86400000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String fg = null, self = c.getPackageName();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED && !self.equals(e.getPackageName()))
                    fg = e.getPackageName();
            }
            return fg;
        } catch (Throwable t) { return null; }
    }

    /** Killable installed apps, sorted: user apps first, then by label. */
    static List<App> candidates(Context c) {
        PackageManager pm = c.getPackageManager();
        Set<String> launchable = new HashSet<>();
        for (String action : new String[]{Intent.ACTION_MAIN}) {
            for (ResolveInfo r : pm.queryIntentActivities(new Intent(action).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0))
                launchable.add(r.activityInfo.packageName);
            for (ResolveInfo r : pm.queryIntentActivities(new Intent(action).addCategory(Intent.CATEGORY_LAUNCHER), 0))
                launchable.add(r.activityInfo.packageName);
        }
        Map<String, Integer> importance = new HashMap<>();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> rp = am.getRunningAppProcesses();
        if (rp != null) for (ActivityManager.RunningAppProcessInfo p : rp)
            if (p.pkgList != null) for (String pkg : p.pkgList) {
                Integer cur = importance.get(pkg);
                if (cur == null || p.importance < cur) importance.put(pkg, p.importance);
            }
        List<App> out = new ArrayList<>();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            boolean launcher = launchable.contains(ai.packageName);
            if (!ai.enabled || !KillPlan.isCandidate(ai.packageName, launcher, sys)) continue;
            App a = new App();
            a.pkg = ai.packageName; a.system = sys; a.hasLauncher = launcher;
            try { a.label = String.valueOf(pm.getApplicationLabel(ai)); }
            catch (Throwable t) { a.label = ai.packageName; }
            Integer imp = importance.get(ai.packageName);
            if (imp != null) a.runningImportance = imp;
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.system == y.system ? x.label.compareToIgnoreCase(y.label) : (x.system ? 1 : -1));
        return out;
    }

    /** Packages with a live foreground-service / perceptible process (e.g. music playing) - never auto-killed. */
    static Set<String> activeImportant(Context c) {
        Set<String> keep = new HashSet<>();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> rp = am.getRunningAppProcesses();
        if (rp != null) for (ActivityManager.RunningAppProcessInfo p : rp)
            if (p.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_PERCEPTIBLE && p.pkgList != null)
                Collections.addAll(keep, p.pkgList);
        return keep;
    }

    /** Kill background processes of every candidate not in keep. Returns [killed, freedKbEstimate]. */
    static long[] kill(Context c, Collection<String> targets) {
        Map<String, Long> before = Sys.meminfo();
        long availBefore = before.containsKey("MemAvailable") ? before.get("MemAvailable") : -1;
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        int killed = 0;
        for (String pkg : targets) {
            try { am.killBackgroundProcesses(pkg); killed++; } catch (Throwable ignored) { }
        }
        try { Thread.sleep(1500); } catch (InterruptedException ignored) { }
        Map<String, Long> after = Sys.meminfo();
        long availAfter = after.containsKey("MemAvailable") ? after.get("MemAvailable") : -1;
        long freed = (availBefore >= 0 && availAfter >= 0) ? availAfter - availBefore : -1;
        return new long[]{killed, freed};
    }
}
