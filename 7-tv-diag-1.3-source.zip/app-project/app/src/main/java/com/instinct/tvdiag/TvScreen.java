package com.instinct.tvdiag;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

/** The TV-side screen: start/stop, the phone address + PIN, and setup status. */
public class TvScreen {
    public static class State {
        public boolean running, usage, dump; public String url, pin, error, pkg = "com.instinct.tvdiag";
    }
    public final ScrollView root; public final Button toggle, usageBtn, cleanBtn;
    final TextView status, addr, pinTv, usageTv, dumpTv, cmds, privacy;
    private final Context c;

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    TextView tv(int sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setTextSize(sp); t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.START);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }
    Button btn(String s) {
        Button b = new Button(c); b.setText(s); b.setTextSize(22); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        StateListDrawable d = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(0xFF2F7DEB); f.setCornerRadius(dp(c, 10)); f.setStroke(dp(c, 3), Color.WHITE);
        GradientDrawable n = new GradientDrawable(); n.setColor(0xFF2A3350); n.setCornerRadius(dp(c, 10));
        d.addState(new int[]{android.R.attr.state_focused}, f); d.addState(new int[]{}, n);
        b.setBackground(d); b.setFocusable(true);
        return b;
    }

    public TvScreen(Context ctx) {
        c = ctx;
        root = new ScrollView(c); root.setBackgroundColor(0xFF121826); root.setFillViewport(true);
        LinearLayout col = new LinearLayout(c); col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(c, 56), dp(c, 32), dp(c, 56), dp(c, 32));
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(col);
        TextView title = tv(30, Color.WHITE, true); title.setText("אבחון ביצועים לטלוויזיה"); col.addView(title);
        status = tv(20, 0xFFB8C2DD, false); col.addView(status);
        LinearLayout box = new LinearLayout(c); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 24), dp(c, 16), dp(c, 24), dp(c, 16));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF1B2540); bg.setCornerRadius(dp(c, 12)); box.setBackground(bg);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2); bl.topMargin = dp(c, 16); bl.bottomMargin = dp(c, 12);
        TextView h = tv(20, 0xFFB8C2DD, false); h.setText("בטלפון (באותה רשת Wi-Fi) פתחו בדפדפן:"); box.addView(h);
        addr = tv(34, 0xFF7CE0B0, true); addr.setTextDirection(View.TEXT_DIRECTION_LTR); box.addView(addr);
        pinTv = tv(26, Color.WHITE, true); box.addView(pinTv);
        col.addView(box, bl);
        toggle = btn("התחל מדידה"); col.addView(toggle, new LinearLayout.LayoutParams(-1, dp(c, 64)));
        cleanBtn = btn("ניקוי זיכרון - הרוג אפליקציות רקע");
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(c, 64)); cl.topMargin = dp(c, 10);
        col.addView(cleanBtn, cl);
        TextView sh = tv(22, Color.WHITE, true); sh.setText("הרשאות אופציונליות לנתונים עמוקים יותר"); sh.setPadding(0, dp(c, 20), 0, dp(c, 4)); col.addView(sh);
        usageTv = tv(19, 0xFFB8C2DD, false); col.addView(usageTv);
        usageBtn = btn("פתח הגדרות גישת שימוש"); LinearLayout.LayoutParams ul = new LinearLayout.LayoutParams(-1, dp(c, 56)); ul.topMargin = dp(c, 6);
        col.addView(usageBtn, ul);
        dumpTv = tv(19, 0xFFB8C2DD, false); dumpTv.setPadding(0, dp(c, 10), 0, 0); col.addView(dumpTv);
        cmds = tv(16, 0xFFE8C97A, false); cmds.setTextDirection(View.TEXT_DIRECTION_LTR); cmds.setTypeface(android.graphics.Typeface.MONOSPACE); col.addView(cmds);
        privacy = tv(16, 0xFF8791AD, false); privacy.setPadding(0, dp(c, 14), 0, 0);
        privacy.setText("הנתונים נשארים ברשת הביתית: השרת מקשיב רק למכשירים ברשת מקומית ודורש את הקוד. שום דבר לא נשלח לאינטרנט, והמדידה פועלת רק כשמפעילים אותה."); col.addView(privacy);
    }

    public void update(State s) {
        status.setText(s.running ? "● המדידה פועלת ברקע. אפשר לצפות בטלוויזיה כרגיל ולבדוק את הטלפון." : "○ המדידה כבויה");
        status.setTextColor(s.running ? 0xFF7CE0B0 : 0xFFB8C2DD);
        toggle.setText(s.running ? "עצור מדידה" : "התחל מדידה");
        if (s.running && s.url != null) { addr.setText(s.url); pinTv.setText("קוד: " + s.pin); }
        else if (s.running) { addr.setText("אין חיבור לרשת מקומית"); pinTv.setText("קוד: " + s.pin); }
        else { addr.setText("http://···:" + DiagService.PORT); pinTv.setText("הכתובת והקוד יופיעו אחרי ההתחלה"); }
        usageTv.setText((s.usage ? "✓ " : "✗ ") + "גישת שימוש: " + (s.usage ? "פעילה. הדשבורד מציג אפליקציה בחזית, זמני שימוש וגודל אחסון."
                : "כבויה. בלעדיה אין נתוני שימוש, אחסון לכל אפליקציה, או קשר בין האפליקציה בחזית לבין הזיכרון."));
        usageBtn.setVisibility(s.usage ? View.GONE : View.VISIBLE);
        dumpTv.setText("זיכרון לפי אפליקציה: אנדרואיד לא מאפשר זאת לאפליקציה רגילה. הדרך המהימנה היא adb ממחשב והדבקת הפלט בדשבורד בטלפון (ההסבר בדשבורד).");
        cmds.setVisibility(s.usage ? View.GONE : View.VISIBLE);
        cmds.setText("adb shell appops set " + s.pkg + " GET_USAGE_STATS allow");
        if (s.error != null) status.setText(status.getText() + "\nשגיאה: " + s.error);
    }
}
