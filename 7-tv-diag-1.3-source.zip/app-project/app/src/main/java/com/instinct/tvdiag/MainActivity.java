package com.instinct.tvdiag;

import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TvScreen screen; private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() { public void run() { refresh(); h.postDelayed(this, 1500); } };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        screen = new TvScreen(this);
        setContentView(screen.root);
        screen.toggle.setOnClickListener(v -> {
            Intent i = new Intent(this, DiagService.class);
            if (DiagService.running) stopService(i); else startForegroundService(i);
            h.postDelayed(this::refresh, 600);
        });
        screen.cleanBtn.setOnClickListener(v -> startActivity(new Intent(this, CleanerActivity.class)));
        screen.usageBtn.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
            catch (Throwable e) { Toast.makeText(this, "מסך ההגדרות לא קיים בטלוויזיה הזו. השתמשו בפקודת adb שמוצגת.", Toast.LENGTH_LONG).show(); }
        });
        screen.toggle.requestFocus();
    }
    private void refresh() {
        TvScreen.State s = new TvScreen.State();
        s.running = DiagService.running; s.pin = DiagService.running ? DiagService.pin : null;
        String ip = Collector.lanIp();
        s.url = ip == null ? null : "http://" + ip + ":" + DiagService.PORT + "/?k=" + DiagService.pin;
        s.usage = Collector.hasUsage(this); s.dump = Collector.hasDump(this); s.error = DiagService.lastError; s.pkg = getPackageName();
        screen.update(s);
    }
    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }
}
