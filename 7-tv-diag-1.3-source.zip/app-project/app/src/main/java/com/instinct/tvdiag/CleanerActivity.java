package com.instinct.tvdiag;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/**
 * "ניקוי זיכרון" - one-tap background-app killer.
 * One tap keeps the app Gil was just using (auto, via usage access when granted)
 * plus a hard system exclusion list, and kills background processes of the rest.
 * Killing is ActivityManager.killBackgroundProcesses: cached/background processes only,
 * apps can restart when opened. Not a force-stop.
 */
public class CleanerActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearLayout listBox; private TextView summary, keptTv, result; private Button killBtn;
    private final Map<String, CheckBox> keepMarks = new HashMap<>();
    private List<AppKiller.App> apps = new ArrayList<>();
    private Set<String> autoKeep = new HashSet<>();
    private String mruLabel = null; private boolean mruKnown = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildShell();
        load();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private TextView tv(int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setGravity(Gravity.START);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(20); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        StateListDrawable d = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(0xFF2F7DEB); f.setCornerRadius(dp(10)); f.setStroke(dp(3), Color.WHITE);
        GradientDrawable n = new GradientDrawable(); n.setColor(0xFF2A3350); n.setCornerRadius(dp(10));
        d.addState(new int[]{android.R.attr.state_focused}, f); d.addState(new int[]{}, n);
        b.setBackground(d); b.setFocusable(true);
        return b;
    }

    private void buildShell() {
        ScrollView root = new ScrollView(this); root.setBackgroundColor(0xFF121826); root.setFillViewport(true);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(56), dp(28), dp(56), dp(28)); col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(col);
        TextView title = tv(28, Color.WHITE, true); title.setText("ניקוי זיכרון"); col.addView(title);
        TextView expl = tv(17, 0xFFB8C2DD, false); expl.setPadding(0, dp(8), 0, dp(4));
        expl.setText("אנדרואיד לא מראה לאפליקציה רגילה מי באמת פעיל ברקע, לכן הרשימה היא של האפליקציות המותקנות. ההריגה משחררת את הזיכרון שלהן כמו סגירה בכוח, והן יכולות להיפתח מחדש כרגיל. הטלוויזיה, הלאונצ׳ר והמערכת אף פעם לא נפגעים.");
        col.addView(expl);
        keptTv = tv(19, 0xFF7CE0B0, true); keptTv.setPadding(0, dp(6), 0, dp(6)); col.addView(keptTv);
        killBtn = btn("הרוג אפליקציות רקע");
        LinearLayout.LayoutParams kl = new LinearLayout.LayoutParams(-1, dp(62)); kl.topMargin = dp(6);
        col.addView(killBtn, kl);
        result = tv(19, 0xFFE8C97A, true); result.setPadding(0, dp(8), 0, dp(4)); col.addView(result);
        TextView listTitle = tv(18, 0xFFB8C2DD, false); listTitle.setPadding(0, dp(10), 0, dp(4));
        listTitle.setText("אפליקציות שייהרגו (אפשר לסמן ✓ כדי לשמור עוד):"); col.addView(listTitle);
        listBox = new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); col.addView(listBox);
        summary = tv(16, 0xFF8791AD, false); summary.setPadding(0, dp(8), 0, 0); col.addView(summary);
        setContentView(root);
        killBtn.setOnClickListener(v -> doKill());
    }

    private void load() {
        new Thread(() -> {
            List<AppKiller.App> a = AppKiller.candidates(this);
            boolean usage = Collector.hasUsage(this);
            String mru = usage ? AppKiller.mostRecentOtherApp(this) : null;
            Set<String> keep = KillPlan.autoKeep(mru, AppKiller.activeImportant(this));
            String label = null;
            if (mru != null) {
                label = mru;
                for (AppKiller.App app : a) if (app.pkg.equals(mru)) { label = app.label; break; }
            }
            final String flabel = label; final boolean fused = usage; final String fmru = mru;
            h.post(() -> {
                apps = a; autoKeep = keep; mruKnown = KillPlan.killAllowed(fused, fmru); mruLabel = flabel;
                if (!fused) {
                    keptTv.setText("כדי שהניקוי יישמור את האפליקציה שצפית בה, חובה להפעיל קודם גישת שימוש (כפתור במסך הראשי). בלעדיה הכפתור נעול בכוונה.");
                } else if (fmru == null) {
                    keptTv.setText("לא הצלחתי לזהות מה הייתה האפליקציה האחרונה, לכן הכפתור נעול בכוונה. פתח שוב את המסך אחרי כניסה לאפליקציית צפייה.");
                } else if (KillPlan.isExcluded(fmru)) {
                    keptTv.setText("האפליקציה האחרונה הייתה מסך הבית, שנשמר תמיד. אפשר לנקות.");
                } else {
                    keptTv.setText("נשמרת אוטומטית: " + mruLabel + " (האפליקציה האחרונה שהשתמשת בה)");
                }
                keptTv.setTextColor(mruKnown ? 0xFF7CE0B0 : 0xFFE8C97A);
                renderList();
            });
        }).start();
    }

    private void renderList() {
        listBox.removeAllViews(); keepMarks.clear();
        for (AppKiller.App app : apps) {
            CheckBox cb = new CheckBox(this);
            cb.setText(app.label + (app.runningImportance <= 400 ? "  (פעילה כרגע)" : ""));
            cb.setTextSize(18); cb.setTextColor(Color.WHITE); cb.setTextDirection(View.TEXT_DIRECTION_RTL);
            cb.setChecked(autoKeep.contains(app.pkg));
            cb.setPadding(dp(14), dp(8), dp(14), dp(8));
            StateListDrawable d = new StateListDrawable();
            GradientDrawable f = new GradientDrawable(); f.setColor(0xFF2F7DEB); f.setCornerRadius(dp(8)); f.setStroke(dp(2), Color.WHITE);
            GradientDrawable n = new GradientDrawable(); n.setColor(0xFF1B2540); n.setCornerRadius(dp(8));
            d.addState(new int[]{android.R.attr.state_focused}, f); d.addState(new int[]{}, n);
            cb.setBackground(d); cb.setFocusable(true);
            cb.setOnCheckedChangeListener((c2, on) -> refreshSummary());
            listBox.addView(cb); keepMarks.put(app.pkg, cb);
        }
        refreshSummary();
        killBtn.requestFocus();
    }

    private void refreshSummary() {
        int kill = 0, keep = 0;
        for (AppKiller.App a : apps) {
            CheckBox cb = keepMarks.get(a.pkg);
            if (cb != null && cb.isChecked()) keep++; else kill++;
        }
        summary.setText("ייהרגו: " + kill + " אפליקציות · יישמרו: " + keep);
        killBtn.setText(mruKnown ? "הרוג אפליקציות רקע (" + kill + ")" : "הניקוי נעול - חסרה גישת שימוש");
        killBtn.setEnabled(mruKnown);
    }

    private void doKill() {
        if (!mruKnown) { result.setText("הניקוי נעול: לא זוהתה האפליקציה שצפית בה, ולא ארוג אותה בטעות."); return; }
        killBtn.setEnabled(false); result.setText("מנקה...");
        new Thread(() -> {
            Set<String> keep = new HashSet<>();
            for (Map.Entry<String, CheckBox> e : keepMarks.entrySet()) if (e.getValue().isChecked()) keep.add(e.getKey());
            List<String> cand = new ArrayList<>();
            for (AppKiller.App a : apps) cand.add(a.pkg);
            long[] r = AppKiller.kill(this, KillPlan.targets(cand, keep));
            h.post(() -> {
                result.setText(KillPlan.hebrewResult((int) r[0], r[1]));
                killBtn.setEnabled(true);
                load(); // refresh running markers
            });
        }).start();
    }
}
