package com.instinct.tvdiag;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import java.io.File;
import java.io.FileOutputStream;

/** Renders the real TV views to actual pixels (Robolectric native graphics, no emulator). */
@RunWith(RobolectricTestRunner.class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = 29)
public class ScreenShotTest {

    private static void shot(View root, String name) throws Exception {
        int w = 1920, h = 1080;
        root.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                     View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        root.layout(0, 0, w, h);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        root.draw(new Canvas(b));
        File out = new File("build/outputs/screens/" + name);
        out.getParentFile().mkdirs();
        try (FileOutputStream f = new FileOutputStream(out)) {
            b.compress(Bitmap.CompressFormat.PNG, 100, f);
        }
        System.out.println("WROTE " + out.getAbsolutePath());
    }

    @Test public void mainScreen() throws Exception {
        Context c = RuntimeEnvironment.getApplication();
        TvScreen s = new TvScreen(c);
        TvScreen.State st = new TvScreen.State();
        st.running = true; st.pin = "4821"; st.url = "http://192.168.1.23:8931/?k=4821";
        st.usage = false; st.dump = false;
        s.update(st);
        shot(s.root, "main-screen.png");
    }
}
