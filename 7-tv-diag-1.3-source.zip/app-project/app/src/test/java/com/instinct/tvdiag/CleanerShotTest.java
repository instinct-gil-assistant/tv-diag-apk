package com.instinct.tvdiag;

import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.shadow.api.Shadow;
import org.robolectric.shadows.ShadowAppOpsManager;
import org.robolectric.shadows.ShadowPackageManager;
import java.io.File;
import java.io.FileOutputStream;

@RunWith(RobolectricTestRunner.class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = 29)
public class CleanerShotTest {

    private static void shot(View root, String name) throws Exception {
        int w = 1920, h = 1080;
        root.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                     View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        root.layout(0, 0, w, h);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        root.draw(new Canvas(b));
        File out = new File("build/outputs/screens/" + name);
        out.getParentFile().mkdirs();
        try (FileOutputStream f = new FileOutputStream(out)) { b.compress(Bitmap.CompressFormat.PNG, 100, f); }
        System.out.println("WROTE " + out.getAbsolutePath());
    }

    private static void addApp(Context c, String pkg, String label, boolean system, boolean launcher) {
        ShadowPackageManager spm = Shadow.extract(c.getPackageManager());
        PackageInfo pi = new PackageInfo();
        pi.packageName = pkg;
        ApplicationInfo ai = new ApplicationInfo();
        ai.packageName = pkg; ai.enabled = true; ai.flags = system ? ApplicationInfo.FLAG_SYSTEM : 0;
        ai.nonLocalizedLabel = label;
        pi.applicationInfo = ai;
        spm.installPackage(pi);
        if (launcher) {
            ResolveInfo ri = new ResolveInfo();
            ri.activityInfo = new ActivityInfo(); ri.activityInfo.packageName = pkg; ri.activityInfo.name = pkg + ".Main";
            spm.addResolveInfoForIntent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), ri);
        }
    }

    @Test public void cleanerScreenUnlocked() throws Exception {
        Context c = RuntimeEnvironment.getApplication();
        addApp(c, "com.netflix.ninja", "נטפליקס", false, true);
        addApp(c, "com.google.android.youtube.tv", "YouTube", true, true);
        addApp(c, "com.spotify.tv.android", "Spotify", false, true);
        Shadow.extract(c.getSystemService(Context.APP_OPS_SERVICE));
        ((ShadowAppOpsManager) Shadow.extract(c.getSystemService(Context.APP_OPS_SERVICE))).setMode("android:get_usage_stats", android.os.Process.myUid(), c.getPackageName(), android.app.AppOpsManager.MODE_ALLOWED);
        org.robolectric.shadows.ShadowUsageStatsManager susm =
                Shadow.extract(c.getSystemService(Context.USAGE_STATS_SERVICE));
        susm.addEvent("com.google.android.tvlauncher", 1000, UsageEvents.Event.ACTIVITY_RESUMED);
        susm.addEvent("com.netflix.ninja", 2000, UsageEvents.Event.ACTIVITY_RESUMED);
        susm.addEvent("com.instinct.tvdiag", 3000, UsageEvents.Event.ACTIVITY_RESUMED);
        ActivityController<CleanerActivity> ctl = Robolectric.buildActivity(CleanerActivity.class).create();
        ctl.resume();
        org.robolectric.shadows.ShadowLooper.idleMainLooper();
        Thread.sleep(400);
        org.robolectric.shadows.ShadowLooper.idleMainLooper();
        shot(ctl.get().getWindow().getDecorView(), "cleaner-screen.png");
    }

    @Test public void cleanerScreenLocked() throws Exception {
        ActivityController<CleanerActivity> ctl = Robolectric.buildActivity(CleanerActivity.class).create();
        ctl.resume();
        org.robolectric.shadows.ShadowLooper.idleMainLooper();
        Thread.sleep(400);
        org.robolectric.shadows.ShadowLooper.idleMainLooper();
        shot(ctl.get().getWindow().getDecorView(), "cleaner-screen-locked.png");
    }
}
