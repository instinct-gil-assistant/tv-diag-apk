package shot
import app.cash.paparazzi.*
import com.android.resources.*
import com.instinct.tvdiag.TvScreen
import org.junit.Rule
import org.junit.Test
class TvShot {
  val tv = DeviceConfig.NEXUS_5.copy(screenWidth = 1920, screenHeight = 1500, xdpi = 320, ydpi = 320, density = Density.XHIGH, softButtons = false, orientation = ScreenOrientation.LANDSCAPE, screenRound = ScreenRound.NOTROUND, size = ScreenSize.XLARGE, ratio = ScreenRatio.LONG)
  @get:Rule val p = Paparazzi(deviceConfig = tv, theme = "android:Theme.DeviceDefault", renderingMode = com.android.ide.common.rendering.api.SessionParams.RenderingMode.NORMAL)
  fun st(r: Boolean, u: Boolean, d: Boolean): TvScreen.State { val s = TvScreen.State(); s.running = r; s.usage = u; s.dump = d; s.url = if (r) "http://192.168.1.23:8765/?k=482913" else null; s.pin = "482913"; return s }
  @Test fun running_noperms() { val v = TvScreen(p.context); v.update(st(true, false, false)); p.snapshot(v.root) }
  @Test fun stopped_noperms() { val v = TvScreen(p.context); v.update(st(false, false, false)); p.snapshot(v.root) }
  @Test fun running_allperms() { val v = TvScreen(p.context); v.update(st(true, true, true)); p.snapshot(v.root) }
}
