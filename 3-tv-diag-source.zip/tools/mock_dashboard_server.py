import json,random,time,http.server,socketserver,re
random.seed(5)
now=int(time.time()*1000);tot=1945000
S=[];fgs=["com.google.android.tvlauncher","com.netflix.ninja","com.google.android.youtube.tv","com.example.bloat.player"]
for i in range(480):
    t=now-(480-i)*15000; fg=fgs[(i//90)%4]
    base={0:700000,1:520000,2:430000,3:260000}[(i//90)%4]
    av=int(max(90000,base+random.gauss(0,60000)-(i%90)*1500))
    S.append(dict(t=t,avail=av,total=tot,low=av<150000,swapFree=0,th=0,fg=fg,free=int(av*0.3)))
P=[]
names=[("com.example.bloat.player",310000),("com.netflix.ninja",260000),("system",180000),("com.google.android.tvlauncher",150000),("com.google.android.gms.persistent",95000),("com.mitv.tvhome",88000)]
for k in range(6):
    P.append(dict(t=now-(6-k)*60000,procs=[dict(n=n,pss=int(p*(0.8+0.4*random.random()))) for n,p in names],totals=["Total RAM: 1,945,000K (status normal)","Free RAM: 90,000K"]))
state=dict(now=dict(t=now,mem=dict(totalKb=tot,availKb=S[-1]['avail'],freeKb=50000,cachedKb=300000,swapTotalKb=0,swapFreeKb=0,lowMem=True,thresholdKb=150000),
 storage=dict(totalB=8e9,freeB=0.9e9),thermal=1,fg=fgs[3],device=dict(model="MiTV-MOOQ0 (mock)",maker="Xiaomi",release="10",sdk=29,patch="2022-08-05",lowRam=False,memClass=192,cores=4,uptimeMs=9*86400000,cpuMhz=[None]*4,loadavg="3.2 2.9 2.5 1/900 1234",psiMemory=None),
 perms=dict(usage=True,dump=True),visibleProcesses=1),samples=S,startedAt=now-480*15000,sampleMs=15000,procHist=P)
apps=[]
for i,(l,p,sy,boot) in enumerate([("Bloat Player","com.example.bloat.player",False,True),("Netflix","com.netflix.ninja",False,False),("YouTube","com.google.android.youtube.tv",True,False),("Mi TV Home","com.mitv.tvhome",True,True),("Wallpaper","com.example.wall",False,True)]):
    apps.append(dict(pkg=p,label=l,system=sy,boot=boot,fgsPerm=boot,overlay=(i==0),services=3,enabled=True,fg7dMs=(5-i)*3600000,lastUsed=now,appB=(300-i*40)*1048576,dataB=(500-i*80)*1048576,cacheB=(120-i*20)*1048576))
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(s):
        p=s.path.split('?')[0]
        if p=='/': b=open('/home/sandbox/android/tvdiag/app/src/main/assets/dashboard.html','rb').read();ct='text/html'
        elif p=='/api/state': b=json.dumps(state).encode();ct='application/json'
        elif p=='/api/apps': b=json.dumps(dict(busy=False,apps=apps)).encode();ct='application/json'
        else: s.send_response(404);s.end_headers();return
        s.send_response(200);s.send_header('Content-Type',ct+'; charset=utf-8');s.end_headers();s.wfile.write(b)
    def log_message(*a):pass
socketserver.TCPServer.allow_reuse_address=True
socketserver.TCPServer(('127.0.0.1',18000),H).serve_forever()
