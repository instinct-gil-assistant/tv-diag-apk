package com.instinct.tvdiag;
import java.net.*;import java.io.*;
public class T {
  static String get(String p) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:18765"+p).openConnection(); int code; try{code=c.getResponseCode();}catch(IOException e){return "ERR";} 
    InputStream is= code<400?c.getInputStream():c.getErrorStream(); String b=new String(is.readAllBytes(),"UTF-8"); return code+" "+b.substring(0,Math.min(40,b.length())).replace("\n"," "); }
  public static void main(String[] a) throws Exception {
    String sample="Applications Memory Usage (in Kilobytes):\nUptime: 1 Realtime: 1\n\nTotal PSS by process:\n    182,345K: com.google.android.tvlauncher (pid 1234 / activities)\n     90,100K: system (pid 800)\n     50,000K: com.foo:remote (pid 99)\n\nTotal PSS by OOM adjustment:\n  1K: x\n\nTotal RAM: 1,812,345K (status normal)\n Free RAM:   612,345K (  1,000K cached pss +  2K cached kernel +  3K free)\n Used RAM: 1K\n Lost RAM: 5K\n     ZRAM: 100K physical used\n";
    Dump.Result r=Dump.parse(sample); for(Dump.Proc p:r.procs) System.out.println(p.name+"|"+p.pid+"|"+p.pssKb); System.out.println(r.totals+" err="+r.error);
    WebServer w=new WebServer(null,18765,"123456",(p,q)->p.equals("/x")?new String[]{"text/plain","hello"}:null); w.start();
    System.out.println(get("/x")); System.out.println(get("/x?k=123456")); System.out.println(get("/nope?k=123456"));
    for(int i=0;i<12;i++) get("/x?k=000000"); System.out.println("after bruteforce: "+get("/x?k=123456"));
    w.stop(); }
}
