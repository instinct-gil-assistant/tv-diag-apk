package com.instinct.tvdiag;

import android.content.Context;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Tiny LAN-only HTTP server. Requires the PIN shown on the TV; refuses non-private client addresses. */
final class WebServer {
    interface Handler { String[] handle(String path, String query); } // {contentType, body} or null for 404
    private final int port; private final String pin; private final Handler h; private final Context ctx;
    private ServerSocket ss; private volatile boolean run;
    private int fails; private long failWindow;

    WebServer(Context c, int port, String pin, Handler h) { this.ctx = c; this.port = port; this.pin = pin; this.h = h; }

    void start() throws IOException {
        ss = new ServerSocket(port); run = true;
        new Thread(() -> {
            while (run) {
                try { final Socket s = ss.accept(); new Thread(() -> serve(s)).start(); }
                catch (IOException e) { if (!run) return; }
            }
        }, "web-accept").start();
    }
    void stop() { run = false; try { if (ss != null) ss.close(); } catch (IOException ignored) { } }

    private static boolean privateAddr(InetAddress a) {
        return a.isSiteLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress();
    }
    private synchronized boolean blocked() {
        long now = System.currentTimeMillis();
        if (now - failWindow > 60000) { failWindow = now; fails = 0; }
        return fails >= 10;
    }
    private synchronized void fail() { fails++; }

    private void serve(Socket s) {
        try {
            s.setSoTimeout(5000);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.ISO_8859_1));
            String line = br.readLine();
            if (line == null) { s.close(); return; }
            String l; while ((l = br.readLine()) != null && !l.isEmpty()) { }
            OutputStream os = s.getOutputStream();
            String[] parts = line.split(" ");
            if (!privateAddr(s.getInetAddress())) { send(os, 403, "text/plain", "forbidden"); s.close(); return; }
            if (parts.length < 2 || !"GET".equals(parts[0])) { send(os, 405, "text/plain", "GET only"); s.close(); return; }
            String path = parts[1], q = "";
            int i = path.indexOf('?'); if (i >= 0) { q = path.substring(i + 1); path = path.substring(0, i); }
            if (blocked()) { send(os, 429, "text/plain", "too many attempts"); s.close(); return; }
            boolean ok = false;
            for (String kv : q.split("&")) if (kv.equals("k=" + pin)) ok = true;
            if (!ok) {
                fail();
                send(os, 401, "text/html; charset=utf-8", "<meta name=viewport content='width=device-width'><body dir=rtl style='font-family:sans-serif;padding:24px'><h3>נדרש קוד</h3><p>הוסיפו לכתובת <code>?k=הקוד</code> כפי שמוצג על מסך הטלוויזיה.</p>");
                s.close(); return;
            }
            String[] r = h.handle(path, q);
            if (r == null) send(os, 404, "text/plain", "not found"); else send(os, 200, r[0], r[1]);
            s.close();
        } catch (Throwable e) { try { s.close(); } catch (IOException ignored) { } }
    }
    private void send(OutputStream os, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String hd = "HTTP/1.1 " + code + " X\r\nContent-Type: " + type + "\r\nContent-Length: " + b.length
                + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        os.write(hd.getBytes(StandardCharsets.ISO_8859_1)); os.write(b); os.flush();
    }
}
