package com.instinct.tvdiag;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;

public class DiagService extends Service {
    static final int PORT = 8765;
    static volatile boolean running; static volatile String pin; static volatile long startedAt;
    static volatile String lastError;

    private static final int SAMPLE_MS = 15000, PROC_EVERY = 4, MAX = 5760;
    private final Deque<JSONObject> samples = new ArrayDeque<>();
    private final Deque<JSONObject> procHist = new ArrayDeque<>();
    private JSONObject latest; private JSONArray appsCache; private long appsAt; private volatile boolean appsBusy;
    private String fg; private long lastEv;
    private WebServer web; private Handler loop; private HandlerThread ht; private int tick;
    private File csv;

    static String pinFor(Context c) {
        SharedPreferences p = c.getSharedPreferences("p", 0);
        String k = p.getString("pin", null);
        if (k == null) { k = String.format(Locale.US, "%06d", new SecureRandom().nextInt(1000000)); p.edit().putString("pin", k).apply(); }
        return k;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (running) return START_NOT_STICKY;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("diag", "Diagnostics", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, "diag").setContentTitle("אבחון טלוויזיה פועל")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        startForeground(1, n);
        pin = pinFor(this); startedAt = System.currentTimeMillis(); lastError = null;
        csv = new File(getFilesDir(), "samples.csv");
        loadCsv();
        try {
            web = new WebServer(this, PORT, pin, this::route); web.start();
        } catch (IOException e) { lastError = "port " + PORT + ": " + e.getMessage(); }
        ht = new HandlerThread("sampler"); ht.start(); loop = new Handler(ht.getLooper());
        lastEv = System.currentTimeMillis() - 60000;
        running = true;
        loop.post(this::sample);
        return START_NOT_STICKY;
    }

    private void loadCsv() {
        if (!csv.exists()) return;
        long cut = System.currentTimeMillis() - 24L * 3600000;
        try (BufferedReader br = new BufferedReader(new FileReader(csv))) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] a = l.split(",", -1);
                if (a.length < 8) continue;
                long t = Long.parseLong(a[0]); if (t < cut) continue;
                JSONObject o = new JSONObject();
                o.put("t", t); o.put("avail", Long.parseLong(a[1])); o.put("total", Long.parseLong(a[2]));
                o.put("low", a[3].equals("1")); o.put("swapFree", Long.parseLong(a[4])); o.put("th", Integer.parseInt(a[5]));
                o.put("fg", a[6].isEmpty() ? JSONObject.NULL : a[6]); o.put("free", Long.parseLong(a[7]));
                samples.add(o);
            }
        } catch (Throwable ignored) { }
    }

    private void sample() {
        if (!running) return;
        try {
            long now = System.currentTimeMillis();
            fg = Collector.foreground(this, lastEv, fg); lastEv = now - 2000;
            JSONObject s = Collector.snapshot(this, fg);
            JSONObject m = s.getJSONObject("mem");
            JSONObject o = new JSONObject();
            o.put("t", now); o.put("avail", m.getLong("availKb")); o.put("total", m.getLong("totalKb"));
            o.put("low", m.getBoolean("lowMem")); o.put("swapFree", m.getLong("swapFreeKb"));
            o.put("th", s.getInt("thermal")); o.put("fg", s.get("fg")); o.put("free", m.getLong("freeKb"));
            synchronized (this) {
                latest = s; samples.add(o); while (samples.size() > MAX) samples.poll();
            }
            try (FileWriter fw = new FileWriter(csv, true)) {
                fw.write(now + "," + o.getLong("avail") + "," + o.getLong("total") + "," + (o.getBoolean("low") ? 1 : 0) + ","
                        + o.getLong("swapFree") + "," + o.getInt("th") + "," + (o.isNull("fg") ? "" : o.getString("fg")) + "," + o.getLong("free") + "\n");
            }
            if (csv.length() > 6_000_000) csv.delete();
            if (tick++ % PROC_EVERY == 0 && Collector.hasDump(this)) {
                Dump.Result r = Dump.run();
                JSONObject ph = new JSONObject(); ph.put("t", now);
                if (r.error != null) ph.put("error", r.error);
                JSONArray ps = new JSONArray();
                for (int i = 0; i < r.procs.size() && i < 40; i++) {
                    Dump.Proc p = r.procs.get(i);
                    ps.put(new JSONObject().put("n", p.name).put("pss", p.pssKb));
                }
                ph.put("procs", ps); ph.put("totals", new JSONArray(r.totals));
                synchronized (this) { procHist.add(ph); while (procHist.size() > 1440) procHist.poll(); }
            }
        } catch (Throwable e) { lastError = String.valueOf(e); }
        if (loop != null) loop.postDelayed(this::sample, SAMPLE_MS);
    }

    private synchronized String[] route(String path, String q) {
        try {
            if (path.equals("/") || path.equals("/index.html")) return new String[]{"text/html; charset=utf-8", asset("dashboard.html")};
            if (path.equals("/api/state")) {
                JSONObject o = new JSONObject();
                o.put("now", latest == null ? JSONObject.NULL : latest);
                JSONArray a = new JSONArray(); for (JSONObject s : samples) a.put(s);
                o.put("samples", a); o.put("startedAt", startedAt); o.put("sampleMs", SAMPLE_MS);
                JSONArray ph = new JSONArray(); for (JSONObject s : procHist) ph.put(s);
                o.put("procHist", ph);
                return new String[]{"application/json; charset=utf-8", o.toString()};
            }
            if (path.equals("/api/apps")) {
                if ((appsCache == null || System.currentTimeMillis() - appsAt > 300000) && !appsBusy) {
                    appsBusy = true;
                    new Thread(() -> { JSONArray a = Collector.apps(this); synchronized (this) { appsCache = a; appsAt = System.currentTimeMillis(); } appsBusy = false; }).start();
                }
                JSONObject o = new JSONObject(); o.put("busy", appsBusy);
                o.put("apps", appsCache == null ? new JSONArray() : appsCache);
                return new String[]{"application/json; charset=utf-8", o.toString()};
            }
            if (path.equals("/samples.csv")) {
                StringBuilder sb = new StringBuilder("time_ms,mem_available_kb,mem_total_kb,low_memory,swap_free_kb,thermal,foreground_pkg,mem_free_kb\n");
                for (JSONObject s : samples) sb.append(s.getLong("t")).append(',').append(s.getLong("avail")).append(',').append(s.getLong("total")).append(',')
                        .append(s.getBoolean("low") ? 1 : 0).append(',').append(s.getLong("swapFree")).append(',').append(s.getInt("th")).append(',')
                        .append(s.isNull("fg") ? "" : s.getString("fg")).append(',').append(s.getLong("free")).append('\n');
                return new String[]{"text/csv; charset=utf-8", sb.toString()};
            }
        } catch (Throwable e) { return new String[]{"text/plain", "error: " + e}; }
        return null;
    }
    private String asset(String n) throws IOException {
        try (InputStream is = getAssets().open(n); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int r; while ((r = is.read(b)) > 0) bo.write(b, 0, r);
            return bo.toString("UTF-8");
        }
    }

    @Override public void onDestroy() {
        running = false;
        if (web != null) web.stop();
        if (ht != null) ht.quit();
        super.onDestroy();
    }
}
