package com.instinct.tvdiag;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import org.json.*;
import java.net.*;
import java.util.*;

final class Collector {
    static boolean hasUsage(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            return a.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), c.getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable e) { return false; }
    }
    static boolean hasDump(Context c) {
        return c.checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED;
    }
    static String lanIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** One memory/thermal/storage sample plus static device facts. */
    static JSONObject snapshot(Context c, String fg) {
        JSONObject o = new JSONObject();
        try {
            Map<String, Long> mi = Sys.meminfo();
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(m);
            o.put("t", System.currentTimeMillis());
            JSONObject mem = new JSONObject();
            long total = mi.containsKey("MemTotal") ? mi.get("MemTotal") : m.totalMem / 1024;
            long avail = mi.containsKey("MemAvailable") ? mi.get("MemAvailable") : m.availMem / 1024;
            mem.put("totalKb", total); mem.put("availKb", avail);
            mem.put("freeKb", mi.containsKey("MemFree") ? mi.get("MemFree") : -1);
            mem.put("cachedKb", mi.containsKey("Cached") ? mi.get("Cached") : -1);
            mem.put("swapTotalKb", mi.containsKey("SwapTotal") ? mi.get("SwapTotal") : 0);
            mem.put("swapFreeKb", mi.containsKey("SwapFree") ? mi.get("SwapFree") : 0);
            mem.put("lowMem", m.lowMemory); mem.put("thresholdKb", m.threshold / 1024);
            o.put("mem", mem);
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            JSONObject st = new JSONObject();
            st.put("totalB", sf.getTotalBytes()); st.put("freeB", sf.getAvailableBytes());
            o.put("storage", st);
            int th = -1;
            try { th = ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus(); } catch (Throwable ignored) { }
            o.put("thermal", th);
            o.put("fg", fg == null ? JSONObject.NULL : fg);
            JSONObject dev = new JSONObject();
            dev.put("model", Build.MODEL); dev.put("maker", Build.MANUFACTURER);
            dev.put("release", Build.VERSION.RELEASE); dev.put("sdk", Build.VERSION.SDK_INT);
            dev.put("patch", Build.VERSION.SECURITY_PATCH);
            dev.put("lowRam", am.isLowRamDevice()); dev.put("memClass", am.getMemoryClass());
            dev.put("cores", Runtime.getRuntime().availableProcessors());
            dev.put("uptimeMs", SystemClock.elapsedRealtime());
            JSONArray freqs = new JSONArray();
            for (int i = 0; i < dev.getInt("cores"); i++) {
                String f = Sys.read("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq", 40);
                try { freqs.put(Long.parseLong(f.trim()) / 1000); } catch (Throwable e) { freqs.put(JSONObject.NULL); }
            }
            dev.put("cpuMhz", freqs);
            String load = Sys.read("/proc/loadavg", 100);
            dev.put("loadavg", load == null ? JSONObject.NULL : load);
            String psi = Sys.read("/proc/pressure/memory", 300);
            dev.put("psiMemory", psi == null ? JSONObject.NULL : psi);
            o.put("device", dev);
            JSONObject pm = new JSONObject();
            pm.put("usage", hasUsage(c)); pm.put("dump", hasDump(c));
            o.put("perms", pm);
            // what an ordinary app is allowed to see of other processes
            List<ActivityManager.RunningAppProcessInfo> rp = am.getRunningAppProcesses();
            o.put("visibleProcesses", rp == null ? 0 : rp.size());
        } catch (Exception e) { try { o.put("error", String.valueOf(e)); } catch (JSONException ignored) { } }
        return o;
    }

    /** Last foreground package, from usage events since 'since'. Null if no usage access. */
    static String foreground(Context c, long since, String prev) {
        if (!hasUsage(c)) return prev;
        try {
            UsageStatsManager us = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            UsageEvents ev = us.queryEvents(since, System.currentTimeMillis());
            UsageEvents.Event e = new UsageEvents.Event();
            String fg = prev;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.getPackageName();
            }
            return fg;
        } catch (Throwable t) { return prev; }
    }

    private static final String[] BOOT = {"android.intent.action.BOOT_COMPLETED"};

    static JSONArray apps(Context c) {
        JSONArray out = new JSONArray();
        try {
            PackageManager pm = c.getPackageManager();
            Set<String> boot = new HashSet<>();
            for (ResolveInfo r : pm.queryBroadcastReceivers(new Intent(Intent.ACTION_BOOT_COMPLETED), 0))
                boot.add(r.activityInfo.packageName);
            Map<String, UsageStats> us = new HashMap<>();
            boolean usage = hasUsage(c);
            StorageStatsManager ssm = (StorageStatsManager) c.getSystemService(Context.STORAGE_STATS_SERVICE);
            if (usage) {
                UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
                long now = System.currentTimeMillis();
                us = u.queryAndAggregateUsageStats(now - 7L * 86400000, now);
            }
            for (PackageInfo base : pm.getInstalledPackages(0)) {
              try {
                PackageInfo pi;
                try { pi = pm.getPackageInfo(base.packageName, PackageManager.GET_PERMISSIONS | PackageManager.GET_SERVICES); }
                catch (Throwable t) { pi = base; }
                ApplicationInfo ai = pi.applicationInfo;
                if (ai == null) continue;
                JSONObject o = new JSONObject();
                boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                o.put("pkg", pi.packageName);
                o.put("label", String.valueOf(pm.getApplicationLabel(ai)));
                o.put("system", sys);
                o.put("boot", boot.contains(pi.packageName));
                boolean fgs = false, overlay = false;
                if (pi.requestedPermissions != null) for (String p : pi.requestedPermissions) {
                    if ("android.permission.FOREGROUND_SERVICE".equals(p)) fgs = true;
                    if ("android.permission.SYSTEM_ALERT_WINDOW".equals(p)) overlay = true;
                }
                o.put("fgsPerm", fgs); o.put("overlay", overlay);
                o.put("services", pi.services == null ? 0 : pi.services.length);
                o.put("enabled", ai.enabled);
                UsageStats u = us.get(pi.packageName);
                if (usage) { o.put("fg7dMs", u == null ? 0 : u.getTotalTimeInForeground()); o.put("lastUsed", u == null ? 0 : u.getLastTimeUsed()); }
                if (usage) {
                    try {
                        StorageStats s = ssm.queryStatsForPackage(StorageManager_UUID(), pi.packageName, android.os.Process.myUserHandle());
                        o.put("appB", s.getAppBytes()); o.put("dataB", s.getDataBytes()); o.put("cacheB", s.getCacheBytes());
                    } catch (Throwable ignored) { }
                }
                out.put(o);
              } catch (Throwable ignored) { }
            }
        } catch (Throwable e) { /* return what we have */ }
        return out;
    }
    private static UUID StorageManager_UUID() { return android.os.storage.StorageManager.UUID_DEFAULT; }
}
