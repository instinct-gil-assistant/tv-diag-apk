package com.instinct.tvdiag;

import java.io.*;
import java.util.*;

final class Sys {
    static String read(String path, int max) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            StringBuilder sb = new StringBuilder(); String l;
            while ((l = br.readLine()) != null && sb.length() < max) sb.append(l).append('\n');
            return sb.toString().trim();
        } catch (Throwable e) { return null; }
    }
    static Map<String, Long> meminfo() {
        Map<String, Long> m = new HashMap<>();
        String s = read("/proc/meminfo", 8000);
        if (s == null) return m;
        for (String line : s.split("\n")) {
            int i = line.indexOf(':'); if (i < 0) continue;
            String v = line.substring(i + 1).replace("kB", "").trim();
            try { m.put(line.substring(0, i), Long.parseLong(v)); } catch (Exception ignored) { }
        }
        return m;
    }
}
