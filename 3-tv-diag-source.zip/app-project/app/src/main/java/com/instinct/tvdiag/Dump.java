package com.instinct.tvdiag;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/** Runs and parses "dumpsys meminfo". Only works if the DUMP permission was granted over ADB. */
final class Dump {
    static final class Proc { String name; int pid; long pssKb; }
    static final class Result { List<Proc> procs = new ArrayList<>(); List<String> totals = new ArrayList<>(); String error; }

    private static final Pattern P = Pattern.compile("^\\s*([\\d,.]+)K: (.+?) \\(pid (\\d+)");

    static Result parse(String out) {
        Result r = new Result();
        boolean in = false;
        for (String line : out.split("\n")) {
            if (line.startsWith("Total PSS by process:")) { in = true; continue; }
            if (in) {
                if (line.trim().isEmpty()) { in = false; continue; }
                Matcher m = P.matcher(line);
                if (m.find()) {
                    Proc p = new Proc();
                    p.pssKb = Long.parseLong(m.group(1).replaceAll("[,.]", ""));
                    p.name = m.group(2);
                    p.pid = Integer.parseInt(m.group(3));
                    r.procs.add(p);
                }
                continue;
            }
            String t = line.trim();
            if (t.startsWith("Total RAM:") || t.startsWith("Free RAM:") || t.startsWith("Used RAM:")
                    || t.startsWith("Lost RAM:") || t.startsWith("ZRAM:")) r.totals.add(t);
        }
        if (r.procs.isEmpty()) r.error = "no process table in output";
        return r;
    }

    static Result run() {
        final StringBuilder sb = new StringBuilder();
        try {
            final Process p = new ProcessBuilder("dumpsys", "meminfo").redirectErrorStream(true).start();
            Thread t = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String l; while ((l = br.readLine()) != null) sb.append(l).append('\n');
                } catch (IOException ignored) { }
            });
            t.start();
            t.join(20000);
            p.destroy();
        } catch (Exception e) {
            Result r = new Result(); r.error = String.valueOf(e); return r;
        }
        String out = sb.toString();
        if (out.contains("Permission Denial")) { Result r = new Result(); r.error = "permission denied"; return r; }
        return parse(out);
    }
}
