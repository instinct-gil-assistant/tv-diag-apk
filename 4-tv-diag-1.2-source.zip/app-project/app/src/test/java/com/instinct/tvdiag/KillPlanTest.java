package com.instinct.tvdiag;

import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class KillPlanTest {

    @Test public void hardExclusionsNeverKillable() {
        for (String pkg : new String[]{
                "com.instinct.tvdiag", "com.google.android.tvlauncher", "android",
                "com.android.systemui", "com.android.settings", "com.android.tv.settings",
                "com.google.android.gms", "com.google.android.gsf",
                "com.google.android.katniss", "com.google.android.inputmethod.latin",
                "com.xiaomi.tv.something", "com.miui.security", "com.mitv.thing",
                "com.mediatek.tv", "com.amlogic.dvb", "com.google.android.tv.remote.service",
                "com.android.vending", "com.android.packageinstaller"}) {
            assertTrue(pkg + " must be excluded", KillPlan.isExcluded(pkg));
        }
    }

    @Test public void heavyMediaAppsAreCandidates() {
        for (String pkg : new String[]{"com.netflix.ninja", "com.google.android.youtube.tv",
                "com.spotify.tv.android", "com.amazon.amazonvideo.livingroom",
                "com.disney.disneyplus", "com.kkbox"}) {
            assertFalse(pkg + " must not be excluded", KillPlan.isExcluded(pkg));
            assertTrue(KillPlan.isCandidate(pkg, true, true));   // preinstalled with launcher
            assertTrue(KillPlan.isCandidate(pkg, true, false));  // user installed with launcher
        }
    }

    @Test public void candidateRules() {
        assertFalse(KillPlan.isCandidate("com.instinct.tvdiag", true, false)); // self
        assertFalse(KillPlan.isCandidate("com.vendor.bg", false, true));       // launcher-less system svc
        assertTrue(KillPlan.isCandidate("com.vendor.bg", false, false));       // user app w/o launcher
        assertTrue(KillPlan.isExcluded(null));
    }

    @Test public void autoKeepIncludesMruAndActiveButNotExclusions() {
        Set<String> keep = KillPlan.autoKeep("com.netflix.ninja",
                Arrays.asList("com.spotify.tv.android", "com.android.systemui", null));
        assertTrue(keep.contains("com.netflix.ninja"));
        assertTrue(keep.contains("com.spotify.tv.android"));
        assertFalse(keep.contains("com.android.systemui"));
        assertEquals(2, keep.size());
        assertTrue(KillPlan.autoKeep(null, null).isEmpty());
    }

    @Test public void targetsSkipKeptAndExcluded() {
        List<String> cand = Arrays.asList("com.netflix.ninja", "a.b", "com.android.systemui");
        List<String> t = KillPlan.targets(cand, new HashSet<>(Arrays.asList("com.netflix.ninja")));
        assertEquals(Arrays.asList("a.b"), t);
    }

    @Test public void hebrewResultHonest() {
        String s = KillPlan.hebrewResult(3, 150 * 1024);
        assertTrue(s.contains("3"));
        assertTrue(s.contains("150"));
        assertTrue(s.contains("הערכה"));
        assertTrue(KillPlan.hebrewResult(0, -1).contains("לא נמצאו"));
        assertTrue(KillPlan.hebrewResult(2, 0).contains("קטן"));
    }

    @Test public void meminfoParse() {
        Map<String, Long> mi = Sys.parseMeminfo("MemTotal: 1873920 kB\nMemAvailable: 295860 kB\nSwapTotal: 409596 kB\n");
        assertEquals(Long.valueOf(1873920), mi.get("MemTotal"));
        assertEquals(Long.valueOf(295860), mi.get("MemAvailable"));
        assertEquals(Long.valueOf(409596), mi.get("SwapTotal"));
    }
}
