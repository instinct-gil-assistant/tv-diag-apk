package com.instinct.tvdiag;

import java.util.*;

/**
 * Pure decision logic for the memory cleaner: which packages may be killed,
 * and which are automatically kept. No Android imports, so it is JVM-testable.
 */
final class KillPlan {

    /** Exact packages that are never killed: self, launcher, core system, Google plumbing, input. */
    static final Set<String> EXACT = new HashSet<>(Arrays.asList(
            "android",
            "com.instinct.tvdiag",
            "com.instinct.tvadb",
            "com.google.android.tvlauncher",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.google.android.katniss",
            "com.google.android.inputmethod.latin",
            "com.google.android.tv.remote.service",
            "com.android.inputmethod.latin",
            "com.android.settings",
            "com.android.tv.settings",
            "com.android.systemui",
            "com.android.vending",
            "com.android.packageinstaller"
    ));

    /** Vendor/system prefixes that are never killed: display, input, tuner and TV plumbing. */
    static final String[] PREFIXES = {
            "com.android.",           // core platform (settings/providers/telecom...)
            "com.miui.", "com.xiaomi.", "com.mitv.",   // Xiaomi TV services
            "com.mediatek.", "com.amlogic.", "com.realtek.", // SoC vendor services
            "com.google.android.tv."  // Google TV framework extras (not youtube.tv)
    };

    static boolean isExcluded(String pkg) {
        if (pkg == null) return true;
        if (EXACT.contains(pkg)) return true;
        for (String p : PREFIXES) if (pkg.startsWith(p)) return true;
        return false;
    }

    /** A package is a kill candidate when the user could plausibly reopen it:
     *  it has a launcher entry, or it is a user-installed/updated app. */
    static boolean isCandidate(String pkg, boolean hasLauncher, boolean system) {
        return !isExcluded(pkg) && (hasLauncher || !system);
    }

    /** Apps kept automatically: the most recently used app (the one now in the
     *  background when the user opens the cleaner) plus apps with a live
     *  foreground/perceptible process (e.g. music playing). */
    static Set<String> autoKeep(String mru, Collection<String> activeImportant) {
        Set<String> keep = new HashSet<>();
        if (mru != null && !isExcluded(mru)) keep.add(mru);
        if (activeImportant != null) for (String p : activeImportant)
            if (p != null && !isExcluded(p)) keep.add(p);
        return keep;
    }

    /** The packages the kill button targets. */
    static List<String> targets(Collection<String> candidates, Set<String> keep) {
        List<String> out = new ArrayList<>();
        for (String pkg : candidates) if (!keep.contains(pkg) && !isExcluded(pkg)) out.add(pkg);
        return out;
    }

    /** Short honest Hebrew result. freedKb is a rough estimate and may be <= 0. */
    static String hebrewResult(int killed, long freedKb) {
        String s = killed == 0 ? "לא נמצאו תהליכי רקע להריגה" : "הורגו תהליכי רקע של " + killed + " אפליקציות";
        if (freedKb > 1024) s += "\nזיכרון שהתפנה (הערכה גסה בלבד): כ-" + (freedKb / 1024) + "MB";
        else s += "\nהזיכרון שהתפנה קטן או שלא ניתן להערכה";
        return s;
    }
}
